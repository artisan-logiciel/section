Following third-party dependencies exist in web_landing:

* highlight.js@10.7.2:
    * BSD 3-Clause License: [highlight.js](highlightjs.txt) 
    * https://github.com/highlightjs/highlight.js/blob/main/LICENSE 