package common

expect fun getPlatformName(): String