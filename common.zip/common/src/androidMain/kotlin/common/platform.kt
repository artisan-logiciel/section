package common

actual fun getPlatformName(): String {
    return "Android"
}