package common

actual fun getPlatformName() = "Desktop"